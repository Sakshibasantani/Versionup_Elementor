<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'version' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'T_c/s{z@MR,M$C_5d=(*k6!C@r(G&FCn,VjXQB7}iS55f4M#hb!^YU]jP#zsyG..' );
define( 'SECURE_AUTH_KEY',  'Pb0*]_SY2(4Xb42d@D$>qzg*qD{2OQiO`0BO/CZJ{<4N5Du793=JouJepfF`BH|q' );
define( 'LOGGED_IN_KEY',    'Z8wxVeW%[q:s=U[zWIX+El82akgs:-lphHTl5LHoHk{b?6j:CP&Hsjn1-}N3#Zrp' );
define( 'NONCE_KEY',        'lE%AJT_c_x*#CKSb)O}m7WY 6H(=)t^9fauwY81AH6*UQs/s2Qc[,X1bBcX?l?z9' );
define( 'AUTH_SALT',        'v%&)q4V_*]8kcy(YHE]4}!HI3Dq#BCW`e3T;/[u8Wt7Nj7a[Uocv7Wn.4}GP)O41' );
define( 'SECURE_AUTH_SALT', 'O_{9US1Oys~S}_i4KYqjp]:z-Y?6TdJ#kkkh`zHxB)O`ZbF$vi*R`6a=^vJ+X5W1' );
define( 'LOGGED_IN_SALT',   '_=)we.iIX&tNT[1>nloT_?ilrQE,Je$;!}vC_,td^[:ggl^vM8WCj8.~54Jo2%)o' );
define( 'NONCE_SALT',       '#n YU1BSnpA0|7[oY-tk miQ)XM!8^/w%u};_uL+$v``.T2zuXqfw^Y*4Wu&-Z~G' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
